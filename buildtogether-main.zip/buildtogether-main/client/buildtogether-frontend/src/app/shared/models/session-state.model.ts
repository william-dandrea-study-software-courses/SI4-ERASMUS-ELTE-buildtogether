


export enum SessionState {
  DISCONNECTED,
  CONNECTED
}
