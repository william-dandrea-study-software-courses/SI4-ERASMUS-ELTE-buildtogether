

export interface TokenResponseModel {
  token: string,
}
