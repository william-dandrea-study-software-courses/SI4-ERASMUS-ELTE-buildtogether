export interface Interest {
    id: number;
    tag: string;
}
